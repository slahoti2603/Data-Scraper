#!/usr/bin/env python
# coding: utf-8

# In[3]:


import requests
from bs4 import BeautifulSoup
import pandas as pd
import os

def scrape_business_data(base_url, search_query, num_pages=3):
    """
    Scrapes business details (name, phone, address, category) from the provided base URL.
    :param base_url: The base URL of the website (e.g., Yellow Pages).
    :param search_query: Search term for the business (e.g., 'restaurants California').
    :param num_pages: Number of pages to scrape.
    :return: DataFrame containing business details.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36"
    }

    business_data = []

    for page in range(1, num_pages + 1):
        params = {"search_terms": search_query, "page": page}
        response = requests.get(base_url, headers=headers, params=params)

        if response.status_code != 200:
            print(f"Failed to fetch data from page {page}. HTTP Status Code: {response.status_code}")
            continue

        soup = BeautifulSoup(response.text, "html.parser")
        listings = soup.find_all("div", class_="result")

        if not listings:
            print(f"No listings found on page {page}.")
            continue

        # Extract business details from each listing
        for listing in listings:
            name = (
                listing.find("a", class_="business-name").text.strip()
                if listing.find("a", class_="business-name") else "N/A"
            )
            phone = (
                listing.find("div", class_="phones").text.strip()
                if listing.find("div", class_="phones") else "N/A"
            )
            address = (
                listing.find("div", class_="street-address").text.strip()
                if listing.find("div", class_="street-address") else "N/A"
            )
            category = (
                listing.find("div", class_="categories").text.strip()
                if listing.find("div", class_="categories") else "N/A"
            )

            business_data.append({
                "Name": name,
                "Phone": phone,
                "Address": address,
                "Category": category
            })
        print(f"Scraped page {page} successfully.")

    # Save the data into a DataFrame
    df = pd.DataFrame(business_data)
    return df

def clean_data(df):
    """
    Cleans the business data by handling duplicates and missing values.
    :param df: DataFrame containing raw business data.
    :return: Cleaned DataFrame.
    """
    df.drop_duplicates(inplace=True)
    df.fillna("Unknown", inplace=True)
    return df

if __name__ == "__main__":
    # Base URL for Yellow Pages or similar directory website
    base_url = "https://www.yellowpages.com/search"

    # Set your search query and number of pages to scrape
    search_query = "restaurants California"  # Change to your desired business type and location
    num_pages = 3  # Number of pages to scrape

    print("Starting the scraping process...")
    raw_data = scrape_business_data(base_url, search_query, num_pages)

    # Check if data was scraped
    if raw_data.empty:
        print("No data was scraped. Please check the website structure or your search query.")
    else:
        clean_data_df = clean_data(raw_data)

        # Specify the output file path
        output_file = r"C:\Users\saksh\OneDrive\Desktop\Data Science Project\data\business_data.csv"
        clean_data_df.to_csv(output_file, index=False)

        # Print confirmation and file location
        print("Data scraping and cleaning completed successfully!")
        print(f"Data saved to: {os.path.abspath(output_file)}")


# In[ ]:




